"""Call upstream bench unchanged, with isolated output and an external resource guard."""
from pathlib import Path
import fcntl, json, os, signal, subprocess, sys, traceback
from search_runner import ROOT, Monitor, environment, save, status
from host_audit import HostAudit

def main():
    case=json.loads(Path(sys.argv[1]).read_text())
    d=ROOT/'official'/case['name'];d.mkdir(parents=True,exist_ok=False)
    lock=Path('<home>/abyss-gpu.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    for k in list(os.environ):
        if k.startswith(('STRATA_','DS4_','MAYA_','ABYSS_','CUDA_')):os.environ.pop(k)
    sys.path[:0]=[str(ROOT/'source'),str(ROOT/'source/tools')]
    import abyss as A
    for f in ['README.md','README.ja.md','docs','bench']:(d/f).symlink_to(ROOT/'source'/f,target_is_directory=f in ['docs','bench'])
    A.ROOT=d
    e=environment(case)
    cfg={'exe':str(ROOT/'build/strata'),'args':['--glm-pack',str(ROOT/'model/pack'),'--max-context','32768','--prefill',str(case.get('prefill','auto'))], 'gpu':list(map(int,case['gpus'].split(','))), 'cwd':str(d), 'tokenizer':str(ROOT/'model/pack/tokenizer'),'backend':'cuda','port':18959,'env':{k:v for k,v in e.items() if k.startswith(('STRATA_','CUDA_'))}}
    if case.get('split') is not None:cfg['args']+=['--layer-split',str(case['split'])]
    path=d/'config.json';save(path,cfg);save(d/'search-config.json',case)
    host=HostAudit(d);monitors=[];processes=[];transcripts=[];orig=subprocess.Popen
    def guarded(args,*a,**kw):
        engine=isinstance(args,(list,tuple)) and str(args[0])==cfg['exe']
        if engine:kw['start_new_session']=True
        p=orig(args,*a,**kw)
        if engine:
            host.attach(p);m=Monitor(d if not monitors else d/'quality-process',p)
            m.directory.mkdir(exist_ok=True);m.__enter__();monitors.append(m);processes.append(p)
            if kw.get('stderr')==subprocess.PIPE:
                original_communicate=p.communicate
                def communicate(*a,**kw):
                    out,err=original_communicate(*a,**kw)
                    (m.directory/'score.stdout.log').write_text(out or '')
                    (m.directory/'score.stderr.log').write_text(err or '')
                    return out,err
                p.communicate=communicate
            elif p.stdout is not None:
                output=(d/'engine.stdout.log').open('w');transcripts.append(output)
                class Reader:
                    def __init__(self,stream):self.stream=stream
                    def readline(self,*a,**kw):
                        line=self.stream.readline(*a,**kw);output.write(line)
                        if line.startswith(('DONE','READY','INFO')):output.flush()
                        return line
                    def __getattr__(self,k):return getattr(self.stream,k)
                p.stdout=Reader(p.stdout)
        return p
    try:
        host.start();subprocess.Popen=guarded
        status(phase='official_deep_bench',case=case['name'])
        rc=A.bench(path,'1.3.109',deep=True,full=False)
        if host.failure:raise RuntimeError(host.failure)
        if any(m.failure for m in monitors):raise RuntimeError([m.failure for m in monitors])
        save(d/'completion.json',{'status':'complete','returncode':rc,'engine_processes':len(processes),'upstream_bench_function_unmodified':True})
    except BaseException as e:
        save(d/'failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
    finally:
        subprocess.Popen=orig
        for p in processes:
            if p.poll() is None:
                os.killpg(p.pid,signal.SIGTERM)
                try:p.wait(20)
                except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
        for m in monitors:m.__exit__()
        for t in transcripts:t.close()
        host.close()

if __name__=='__main__':main()
