"""Isolated native Abyss benchmark; no system or original model writes."""
from pathlib import Path
import argparse, fcntl, hashlib, json, os, queue, signal, subprocess, threading, time, traceback
from host_audit import HostAudit

ROOT = Path(__file__).resolve().parent

def save(p, x):
    p.write_text(json.dumps(x, indent=2) + '\n')

def cmd(a):
    return subprocess.check_output(a, text=True, timeout=30)

def status(**x):
    x['time'] = time.time()
    save(ROOT / 'progress.json', x)
    print(json.dumps(x), flush=True)

class Monitor:
    def __init__(self, directory, process):
        self.directory, self.process = directory, process
        self.stop, self.failure = threading.Event(), None
        self.thread = threading.Thread(target=self.loop, daemon=True)
    def loop(self):
        with (self.directory / 'telemetry.jsonl').open('w') as out:
            while not self.stop.is_set():
                try:
                    raw = cmd(['nvidia-smi', '--query-gpu=index,name,temperature.gpu,memory.used,utilization.gpu,pcie.link.gen.current,pcie.link.width.current,clocks_event_reasons.hw_thermal_slowdown,clocks_event_reasons.sw_thermal_slowdown,power.draw,clocks.sm,clocks.mem', '--format=csv,noheader,nounits'])
                    keys = ['index','name','temperature_c','memory_mib','util_percent','pcie_gen','pcie_width','hw_thermal','sw_thermal','power_w','sm_clock_mhz','memory_clock_mhz']
                    gpus = [dict(zip(keys, map(str.strip, line.split(',')))) for line in raw.splitlines()]
                    mem = {l.split(':')[0]:int(l.split()[1])*1024 for l in Path('/proc/meminfo').read_text().splitlines()}
                    row = {'time':time.time(),'gpus':gpus,'available_bytes':mem['MemAvailable'],'swap_used_bytes':mem['SwapTotal']-mem['SwapFree']}
                    out.write(json.dumps(row)+'\n'); out.flush()
                    if any(float(g['temperature_c']) >= (90 if '5000' in g['name'] else 85) or g['hw_thermal'].lower()=='active' or g['sw_thermal'].lower()=='active' for g in gpus) or row['available_bytes'] < 6*2**30 or row['swap_used_bytes'] > 2**30:
                        raise RuntimeError('temperature/thermal/RAM/swap guard')
                except Exception as e:
                    self.failure = repr(e)
                    if self.process.poll() is None: os.killpg(self.process.pid, signal.SIGTERM)
                    return
                self.stop.wait(2)
    def __enter__(self): self.thread.start(); return self
    def __exit__(self,*_): self.stop.set(); self.thread.join(35)

def environment(cfg):
    env = {k:v for k,v in os.environ.items() if not k.startswith(('STRATA_','DS4_','MAYA_','ABYSS_','CUDA_'))}
    env.update({'CUDA_DEVICE_ORDER':'PCI_BUS_ID','CUDA_VISIBLE_DEVICES':cfg['gpus'],
                'STRATA_GLM_NO_REUSE':'1','STRATA_GLM_USAGE':'0',
                'STRATA_GLM_RAM_GB':str(cfg.get('ram_gib',90)),
                'STRATA_GLM_CPU_LANE':str(cfg.get('threads',12)),
                'STRATA_Q4X_MTP':str(ROOT/'mtp'),
                'STRATA_GLM_SPLIT_LOG':'1'})
    if cfg.get('prior')=='shipped':
        env['STRATA_GLM_PRIOR']=str(ROOT/'source/data/expert_counts/qwen38-flash-next.txt')
    env.update({k:str(v) for k,v in cfg.get('env',{}).items()})
    return env

def run_case(cfg, fixtures):
    d=ROOT/'runs'/cfg['name']; d.mkdir(parents=True,exist_ok=False)
    argv=[str(ROOT/'build/strata'),'--serve','--glm-pack',str(ROOT/'model/pack'),'--max-context','32768','--prefill',str(cfg.get('prefill','auto'))]
    if cfg.get('split') is not None: argv+=['--layer-split',str(cfg['split'])]
    env=environment(cfg)
    save(d/'config.json',cfg)
    save(d/'settings.json',{'command':argv,'environment':{k:v for k,v in env.items() if k.startswith(('STRATA_','CUDA_'))},'fixtures':[{k:v for k,v in f.items() if k!='ids'} for f in fixtures], 'dispatch':'next GEN immediately after DONE; full independent prompts; no conversation reuse'})
    host=HostAudit(d); proc=None; threads=[]; events=queue.Queue(); stdout=[]; start=time.monotonic()
    def event(deadline):
        t,l=events.get(timeout=max(.01,deadline-time.monotonic()))
        if l is None or l.startswith('ERR'):raise RuntimeError('engine stopped: '+str(l))
        return t,l
    try:
        host.start()
        proc=subprocess.Popen(argv,env=env,cwd=d,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1,start_new_session=True)
        host.attach(proc)
        def readout():
            with (d/'protocol-timeline.jsonl').open('w') as out:
                for line in proc.stdout:
                    t=time.monotonic();stdout.append(line)
                    if not line.startswith('T '):out.write(json.dumps({'elapsed_s':t-start,'line':line.rstrip()})+'\n');out.flush()
                    events.put((t,line.rstrip()))
            events.put((time.monotonic(),None))
        def readerr():
            with (d/'engine.stderr.log').open('w') as out:
                for line in proc.stderr:out.write(line);out.flush()
        for fn in [readout,readerr]:
            t=threading.Thread(target=fn,daemon=True);t.start();threads.append(t)
        with Monitor(d,proc) as monitor:
            status(phase='loading',case=cfg['name'])
            while not event(start+900)[1].startswith('READY'):pass
            commands=[f"GEN {f['cap']} temperature=0 top_p=1 top_k=0 min_p=0 seed=42 spec={cfg.get('spec',1)} cpu_threads={cfg.get('threads',12)} "+','.join(map(str,f['ids']))+'\n' for f in fixtures]
            sends={};rows=[]
            def dispatch(i):
                sends[i]=time.monotonic();proc.stdin.write(commands[i]);proc.stdin.flush()
            dispatch(0)
            for i,f in enumerate(fixtures):
                status(phase='request',case=cfg['name'],fixture=f['name'],warmup=f['warmup'])
                tokens=[]; first=None; previous_done=rows[-1]['done_monotonic'] if rows else None
                while True:
                    t,l=event(sends[i]+1800)
                    if l.startswith('T '):
                        if first is None:first=t
                        tokens.append(int(l.split()[1]))
                    elif l.startswith('DONE '):
                        if i+1<len(fixtures):dispatch(i+1)
                        fields=l.split();pms,dms=float(fields[3]),float(fields[4])
                        assert int(fields[1])==len(tokens)==f['cap'], l
                        assert int(fields[2])==len(f['ids']) and int(fields[8])==0,l
                        row={'case':cfg['name'],'fixture':f['name'],'warmup':f['warmup'],'input_tokens':len(f['ids']),'output_tokens':len(tokens),'input_ids_sha256':f['sha256'],'output_ids':tokens,'output_ids_sha256':hashlib.sha256(','.join(map(str,tokens)).encode()).hexdigest(),'prefill_ms':pms,'decode_ms':dms,'prefill_tps':len(f['ids'])*1000/pms,'decode_tps':len(tokens)*1000/dms,'wall_s':t-sends[i],'ttft_s':first-sends[i],'wall_minus_native_ms':(t-sends[i])*1000-pms-dms,'draft_accepted':int(fields[6]),'draft_offered':int(fields[7]),'reuse':int(fields[8]),'done':l,'send_monotonic':sends[i],'done_monotonic':t,'gap_after_previous_done_ms':None if previous_done is None else (sends[i]-previous_done)*1000}
                        rows.append(row);save(d/(f['name']+'.json'),row)
                        print(json.dumps({k:v for k,v in row.items() if k!='output_ids'}),flush=True)
                        break
            proc.stdin.write('QUIT\n');proc.stdin.flush();proc.wait(timeout=90)
            if proc.returncode:raise RuntimeError('exit '+str(proc.returncode))
            if monitor.failure:raise RuntimeError(monitor.failure)
        if host.failure:raise RuntimeError(host.failure)
        save(d/'result.json',{'status':'complete','rows':rows})
        return rows
    except BaseException as e:
        save(d/'failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
    finally:
        if proc is not None and proc.poll() is None:
            os.killpg(proc.pid,signal.SIGTERM)
            try:proc.wait(20)
            except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
        for t in threads:t.join(5)
        host.close();(d/'engine.stdout.log').write_text(''.join(stdout))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('plan');a=ap.parse_args()
    lock=Path('<home>/abyss-gpu.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    plan=json.loads(Path(a.plan).read_text()); all_f=json.loads((ROOT/'fixtures.json').read_text())
    for cfg in plan['cases']:
        d=ROOT/'runs'/cfg['name']
        if (d/'result.json').exists():continue
        fs=[]
        for req in cfg.get('requests',plan['requests']):
            f=dict(next(x for x in all_f if x['name']==req['fixture']));f['cap']=req['cap'];fs.append(f)
        run_case(cfg,fs)
    status(phase='complete',plan=a.plan)

if __name__=='__main__':main()
