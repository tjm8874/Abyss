"""Separate long-context teacher-forced comparison to the full-GPU baseline."""
from pathlib import Path
import fcntl, hashlib, json, os, re, signal, subprocess, sys
import numpy as np
from search_runner import ROOT, Monitor, environment, save, status
from host_audit import HostAudit

def main():
    plan=json.loads(Path(sys.argv[1]).read_text());lock=Path('<home>/abyss-gpu.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    root=ROOT/'long-quality';root.mkdir(exist_ok=True)
    external=plan.get('external_reference')
    if external:
        ids=json.loads((ROOT/external['tokens']).read_text())['ids']
    else:
        fixture=next(x for x in json.loads((ROOT/'fixtures.json').read_text()) if x['name']=='input-16384-trial-01')
        prior=json.loads((ROOT/'runs'/plan['baseline_output_case']/'input-16384-trial-01.json').read_text())
        ids=fixture['ids']+prior['output_ids'][:256]
    save(root/'tokens.json',{'ids':ids,'prefix_tokens':16384,'continuation_tokens':256,'scored_tokens':255,'score_note':'Upstream SCORE skips the first continuation token at c; 255 later continuation positions are scored. Prefill uses all but the last prompt token as GEN does.','sha256':hashlib.sha256(','.join(map(str,ids)).encode()).hexdigest(),'reference':external.get('description','external full-GPU reference') if external else 'relative to this host single PRO5000 token path, not an independent model reference'})
    ref=ROOT/external['topk'] if external else root/'single5000.topk'
    for i,cfg in enumerate(plan['cases']):
        if (root/cfg['name']/'result.json').exists():continue
        d=root/cfg['name'];d.mkdir(exist_ok=False);host=HostAudit(d);p=None
        env=environment(cfg);env.update(STRATA_GLM_SCORE='16384',STRATA_GLM_SCORE_PREFILL='1')
        make_reference=i==0 and not external
        if make_reference:env['STRATA_GLM_SCORE_DUMP']=str(d/'dump.bin')
        else:env['STRATA_GLM_SCORE_TOPK']=str(ref)
        args=[str(ROOT/'build/strata'),'--glm-pack',str(ROOT/'model/pack'),'--max-context','32768','--prefill',str(cfg.get('prefill','auto')),'--layer-split',str(cfg['split']),'--tokens',','.join(map(str,ids))]
        save(d/'settings.json',{'config':cfg,'environment':{k:v for k,v in env.items() if k.startswith(('STRATA_','CUDA_'))},'args_without_token_list':args[:-1]+['<tokens.json ids>']})
        try:
            host.start();status(phase='long_context_quality',case=cfg['name'])
            with (d/'stdout.log').open('w') as out,(d/'stderr.log').open('w') as err:
                p=subprocess.Popen(args,env=env,cwd=d,stdout=out,stderr=err,start_new_session=True);host.attach(p)
                with Monitor(d,p) as monitor:
                    p.wait(900)
                    if p.returncode or host.failure or monitor.failure:raise RuntimeError((p.returncode,host.failure,monitor.failure))
            score=next(x for x in (d/'stdout.log').read_text().splitlines() if x.startswith('SCORE '));print(cfg['name'],score,flush=True)
            if make_reference:
                n=int(re.search(r'SCORE (\d+) tokens',score).group(1));lp=np.fromfile(d/'dump.bin',dtype=np.float32).reshape(n,-1)
                assert np.isfinite(lp).all()
                top=np.argpartition(-lp,31,axis=1)[:,:32];val=np.take_along_axis(lp,top,axis=1);order=np.argsort(-val,axis=1)
                top=np.take_along_axis(top,order,axis=1).astype(np.int32);val=np.take_along_axis(val,order,axis=1).astype(np.float32)
                with ref.open('wb') as f:
                    np.array([32],dtype=np.int32).tofile(f)
                    for a,b in zip(top,val):a.tofile(f);b.tofile(f)
                (d/'dump.bin').unlink()
            save(d/'result.json',{'status':'complete','score':score})
        finally:
            if p is not None and p.poll() is None:
                os.killpg(p.pid,signal.SIGTERM)
                try:p.wait(20)
                except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
            host.close()
    status(phase='complete',plan=sys.argv[1])

if __name__=='__main__':main()
