"""Paired official-version benchmarks, exclusive per host, with guarded service restoration."""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,signal,subprocess,sys,time,traceback,urllib.request
R=Path(__file__).resolve().parent
HOST=sys.argv[1];assert HOST in ['dual-pro-system','geforce-system']
OLD=Path('<v109-workdir>')
PREV=Path('<v111-workdir>')
PINS={111:'5e8b9c44fec443fd1d0c9140885c47973f7970b4',112:'c3d4e923b6df8027fc5a13aa2f6b22f6771e9150'}
def save(name,x):(R/name).write_text(json.dumps(x,indent=2)+'\n')
def call(a,check=True):return subprocess.run(a,capture_output=True,text=True,check=check)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def properties(u):return call(['systemctl','--user','show',u,'--property=Id,ActiveState,SubState,MainPID']).stdout
def queues(units):
 out={};opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
 for u in units:
  pid=int(call(['systemctl','--user','show',u,'--property=MainPID','--value']).stdout)
  a=Path(f'/proc/{pid}/cmdline').read_bytes().decode().split('\0')
  host=a[a.index('--listen')+1] if '--listen' in a else '127.0.0.1';host='127.0.0.1' if host in ['0.0.0.0','::'] else host
  port=a[a.index('--port')+1] if '--port' in a else '8188'
  q=json.load(opener.open('http://'+host+':'+port+'/queue',timeout=4))
  out[u]={'running':len(q['queue_running']),'pending':len(q['queue_pending'])}
  assert not q['queue_running'] and not q['queue_pending'],'Queued or active other work; do not stop service'
 return out
def ticks(pid):
 f=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split();return int(f[11])+int(f[12])
lock=Path('<home>/abyss-gpu.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
units=['gpu-service-A','gpu-service-B'] if HOST=='geforce-system' else []
before={u:properties(u) for u in units};active=[u for u in units if call(['systemctl','--user','is-active',u],False).stdout.strip()=='active']
save('services-before.json',before)
if active:
 q=queues(active);pids={int(call(['systemctl','--user','show',u,'--property=MainPID','--value']).stdout) for u in active};last=time.monotonic();prev={p:ticks(p) for p in pids};idle=[]
 for _ in range(5):
  time.sleep(2);now=time.monotonic();cur={p:ticks(p) for p in pids}
  gpu=call(['nvidia-smi','--query-gpu=index,utilization.gpu,memory.used','--format=csv,noheader,nounits']).stdout
  apps={int(x) for x in call(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader']).stdout.splitlines() if x.strip()}
  cpu=sum(cur[p]-prev[p] for p in pids)/os.sysconf('SC_CLK_TCK')/(now-last)
  assert apps<=pids and cpu<.2 and all(float(l.split(',')[1])<=5 for l in gpu.splitlines()),'Service or independent GPU work active'
  idle.append({'time':time.time(),'gpu':gpu,'service_cpu_cores':cpu,'apps_only_services':True});prev,last=cur,now
 save('services-idle-proof.json',{'first_queues':q,'final_queues':queues(active),'samples':idle})
def interrupted(*_):raise KeyboardInterrupt('Our paired benchmark interrupted')
signal.signal(signal.SIGTERM,interrupted)
try:
 if active:call(['systemctl','--user','stop',*active])
 for u in active:assert call(['systemctl','--user','is-active',u],False).stdout.strip()!='active'
 from host_audit import HostAudit
 from search_runner import Monitor,run_case
 save('inventory.json',{k:call(a).stdout for k,a in {'gpu':['nvidia-smi','--query-gpu=index,name,memory.total,driver_version,power.limit,pcie.link.gen.max,pcie.link.width.max','--format=csv,noheader,nounits'],'kernel':['uname','-r'],'cpu':['lscpu'],'mem':['free','-b'],'mount':['findmnt','-T',str(OLD/'model'),'--output','TARGET,SOURCE,FSTYPE'],'disk':['df','-h',str(R)]}.items()})
 d=R/'build-preflight';d.mkdir(exist_ok=True);audit=HostAudit(d);proc=None
 try:
  audit.start()
  src=R/'source'
  if not src.exists():call(['git','clone','--no-hardlinks','--no-checkout',str(PREV/'source' if HOST=='geforce-system' else OLD/'source'),str(src)])
  call(['git','-C',str(src),'fetch','https://github.com/zephel01/Abyss.git','tag','v1.3.112'])
  call(['git','-C',str(src),'checkout','--detach',PINS[112]])
  assert call(['git','-C',str(src),'rev-parse','HEAD']).stdout.strip()==PINS[112]
  assert not call(['git','-C',str(src),'status','--porcelain']).stdout.strip()
  if HOST=='dual-pro-system':
   control=R/'source111'
   if not control.exists():call(['git','clone','--no-hardlinks','--no-checkout',str(src),str(control)])
   call(['git','-C',str(control),'checkout','--detach',PINS[111]])
   tool=Path('<python-env>/.venv/bin');nvcc='/usr/local/cuda-13.0/bin/nvcc';ggml='<llama-source>'
   versions=[(111,control,R/'build111'),(112,src,R/'build')]
  else:
   control=PREV/'source';tool=Path('<toolchain-root>/.venv/bin');nvcc='<cuda-toolkit>/bin/nvcc';ggml=str(OLD/'llama.cpp');versions=[(112,src,R/'build')]
   assert sha(PREV/'build/strata')=='261fd3e975e28533af574170dc4177ca2547b6ab8e809101406bb5f676421422'
   assert call(['git','-C',ggml,'rev-parse','HEAD']).stdout.strip()=='3cf03257f219afbe7334045ff7c6a06ac68c627d'
  assert (control/'VERSION').read_text().strip()=='1.3.111'
  assert call(['git','-C',str(control),'rev-parse','HEAD']).stdout.strip()==PINS[111]
  assert not call(['git','-C',str(control),'status','--porcelain']).stdout.strip()
  assert sha(src/'data/expert_counts/qwen38-flash-next.txt')==sha(control/'data/expert_counts/qwen38-flash-next.txt')=='d62f4f0da4e8de44e05fdac38e9965855df12d64f6d21df29d05bdfc246ed721'
  commands={};provenance={}
  previous_provenance=json.loads((R/'build-provenance.json').read_text())['versions'] if (R/'build-provenance.json').exists() else {}
  for v,source,build in versions:
   if str(v) in previous_provenance and (build/'strata').exists() and sha(build/'strata')==previous_provenance[str(v)]['binary_sha256']:
    provenance[str(v)]=dict(previous_provenance[str(v)],reused_after_contention_retry=True);print('BUILD_REUSED '+str(v),flush=True);continue
   cfg=[str(tool/'cmake'),'-S',str(source),'-B',str(build),'-G','Ninja','-DCMAKE_MAKE_PROGRAM='+str(tool/'ninja'),'-DSTRATA_ENABLE_CUDA=ON','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CUDA_COMPILER='+nvcc,'-DCMAKE_CUDA_ARCHITECTURES=120a','-DSTRATA_BUILD_TESTS=OFF','-DSTRATA_GGML_DIR='+ggml]
   buildcmd=[str(tool/'cmake'),'--build',str(build),'--target','strata','-j4'];commands[str(v)]=[cfg,buildcmd];save('build-commands.json',commands)
   with (R/f'build-v{v}.log').open('w') as out:
    for args in [cfg,buildcmd]:
     proc=subprocess.Popen(args,stdout=out,stderr=subprocess.STDOUT,start_new_session=True);audit.attach(proc)
     with Monitor(d,proc) as mon:
      proc.wait(1800)
      if proc.returncode or audit.failure or mon.failure:raise RuntimeError((proc.returncode,audit.failure,mon.failure))
   provenance[str(v)]={'version':(source/'VERSION').read_text().strip(),'commit':PINS[v],'binary_sha256':sha(build/'strata'),'source_clean':not call(['git','-C',str(source),'status','--porcelain']).stdout.strip(),'finished_at':time.time()}
   print('BUILD_COMPLETE '+str(v),flush=True)
  if HOST=='geforce-system':provenance['111']={'version':'1.3.111','commit':PINS[111],'binary_sha256':sha(PREV/'build/strata'),'reused_same_host_previous_binary':True}
  save('build-provenance.json',{'host':HOST,'ggml_commit':'3cf03257f219afbe7334045ff7c6a06ac68c627d','versions':provenance,'compiler':call([nvcc,'--version']).stdout})
 finally:
  if proc is not None and proc.poll() is None:os.killpg(proc.pid,signal.SIGTERM);proc.wait(30)
  audit.close()
 (R/'model/pack').mkdir(parents=True,exist_ok=True)
 for f in (OLD/'model').glob('*.gguf'):
  if not (R/'model'/f.name).exists():(R/'model'/f.name).symlink_to(f.resolve())
 for f in (OLD/'model/pack').iterdir():
  target=R/'model/pack'/f.name
  if target.exists():continue
  if f.is_symlink():target.symlink_to(f.resolve(),target_is_directory=f.is_dir())
  else:shutil.copyfile(f,target)
 if not (R/'mtp').exists():(R/'mtp').symlink_to((OLD/'mtp').resolve(),target_is_directory=True)
 files=list((R/'model').glob('*.gguf'))+[R/'model/pack'/n for n in ['dense.bin','index.txt','native_experts.txt']]+list((R/'mtp').iterdir())
 stamps={str(p.resolve()):[p.stat().st_size,p.stat().st_mtime_ns] for p in files};save('model-preservation-before.json',stamps)
 plan=json.loads((R/(HOST+'-plan.json')).read_text());fixtures=json.loads((R/'fixtures.json').read_text());summary=[]
 for cfg in plan['cases']:
  if (R/'runs'/cfg['name']/'result.json').exists():continue
  fs=[]
  for req in plan['requests']:
   f=dict(next(f for f in fixtures if f['name']==req['fixture']));f['cap']=req['cap'];fs.append(f)
  rows=run_case(cfg,fs);summary.append({'case':cfg['name'],'status':'complete','requests':len(rows)});save('speed-case-summary.json',summary)
 print('SPEED_CASES_COMPLETE',flush=True)
 if HOST=='dual-pro-system':
  from long_quality import main as quality
  os.environ['ABYSS_PARENT_HOLDS_LOCK']='1';sys.argv=[str(R/'long_quality.py'),str(R/'quality-plan.json')];quality()
  print('SEPARATE_QUALITY_COMPLETE',flush=True)
 after={str(p.resolve()):[p.stat().st_size,p.stat().st_mtime_ns] for p in files};assert stamps==after
 metadata=[R/'model/pack/index.txt',R/'model/pack/native_experts.txt',R/'mtp/dense.txt',R/'source/data/expert_counts/qwen38-flash-next.txt']
 save('model-preservation-after.json',{'same_size_mtime':True,'files':after,'metadata_sha256':{p.name:sha(p) for p in metadata}})
 save('execution-complete.json',{'time':time.time(),'speed_processes':len(plan['cases']),'forced_quality_processes':2 if HOST=='dual-pro-system' else 0})
except BaseException as e:
 save('execution-failure.json',{'error':repr(e),'traceback':traceback.format_exc(),'time':time.time()});raise
finally:
 if active:call(['systemctl','--user','start',*active])
 restored=all(call(['systemctl','--user','is-active',u],False).stdout.strip()=='active' for u in active)
 save('services-restored.json',{'before':before,'after':{u:properties(u) for u in units},'prior_active':active,'restored':restored,'time':time.time()})
 print('SERVICES_RESTORED '+str(restored),flush=True)
 assert restored
