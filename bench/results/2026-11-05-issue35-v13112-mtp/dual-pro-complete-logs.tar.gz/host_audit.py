"""Read-only, per-process CPU/IO audit; stops only our own engine on contention."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import threading
import time

class HostAudit:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.process = None
        self.stop = threading.Event()
        self.failure = None
        self.samples = 0
        self.quiet_samples = 0
        self.hz = os.sysconf('SC_CLK_TCK')
        self.page = os.sysconf('SC_PAGE_SIZE')
        self.thread = threading.Thread(target=self.loop, daemon=True)

    def processes(self):
        result = {}
        for path in Path('/proc').iterdir():
            if not path.name.isdigit():
                continue
            try:
                line = (path / 'stat').read_text()
                end = line.rfind(')')
                fields = line[end + 2:].split()
                if fields[0] == 'Z':
                    continue
                cmd = (path / 'cmdline').read_bytes()
                if not cmd:
                    continue
                io = {}
                try:
                    for s in (path / 'io').read_text().splitlines():
                        k, v = s.split(':', 1)
                        io[k] = int(v)
                except PermissionError:
                    pass
                pid = int(path.name)
                result[pid] = {'ppid': int(fields[1]), 'state': fields[0], 'start': int(fields[19]), 'ticks': int(fields[11]) + int(fields[12]), 'rss': int(fields[21]) * self.page, 'io': io, 'name': line[line.index('(') + 1:end], 'heavy_kind': any(x in cmd.lower() for x in [b'tools.convert', b'convert_infernix.py', b'continue_builds.py', b'/nvcc', b'/ptxas', b'/cc1plus', b'/ninja', b'cmake --build'])}
            except (OSError, ValueError, IndexError):
                continue
        return result

    def own_pids(self, processes):
        own = {os.getpid()}
        if self.process:
            own.add(self.process.pid)
        changed = True
        while changed:
            before = len(own)
            own.update(pid for pid, p in processes.items() if p['ppid'] in own)
            changed = len(own) != before
        parent = processes.get(os.getpid(), {}).get('ppid')
        while parent and parent in processes and parent not in own:
            own.add(parent)
            parent = processes[parent]['ppid']
        return own

    def loop(self):
        previous, last_time, old_disk = {}, time.monotonic(), None
        with (self.directory / 'host-activity.jsonl').open('w') as stream:
            while not self.stop.is_set():
                try:
                    now = time.monotonic()
                    interval = now - last_time
                    current = self.processes()
                    own = self.own_pids(current)
                    active, total_cpu, total_io, reasons = [], 0.0, 0, []
                    for pid, p in current.items():
                        if pid in own or p['name'] in ['nvidia-smi', 'ps', 'sshd', 'ssh']:
                            continue
                        old = previous.get(pid)
                        old = old if old and old['start'] == p['start'] else None
                        ticks = max(0, p['ticks'] - old['ticks']) if old else 0
                        cpu_ms = ticks * 1000 / self.hz
                        io_bytes = sum(max(0, p['io'].get(k, 0) - old['io'].get(k, 0)) for k in ['read_bytes', 'write_bytes']) if old else 0
                        char_bytes = sum(max(0, p['io'].get(k, 0) - old['io'].get(k, 0)) for k in ['rchar', 'wchar']) if old else 0
                        total_cpu += cpu_ms
                        total_io += io_bytes
                        key = hashlib.sha256(f"{pid}/{p['start']}".encode()).hexdigest()[:12]
                        if cpu_ms or io_bytes or p['rss'] > 32 * 2**20:
                            active.append({'process_key': key, 'name': p['name'], 'state': p['state'], 'cpu_ms': cpu_ms, 'io_bytes': io_bytes, 'io_char_bytes': char_bytes, 'rss_bytes': p['rss'], 'known_build_or_conversion': p['heavy_kind']})
                        if old and p['state'] != 'T' and p['heavy_kind'] and (cpu_ms > 5 or io_bytes > 2**20):
                            reasons.append('active independent build/conversion')
                        if p['rss'] > 2 * 2**30:
                            reasons.append('independent process RSS above 2 GiB')
                        if old and interval > .5 and char_bytes / interval > 100 * 2**20:
                            reasons.append('independent process stream IO above 100 MiB/s')
                    if interval > .5 and total_cpu / (interval * 1000) > .25:
                        reasons.append('independent CPU use above 0.25 core')
                    if interval > .5 and total_io / interval > 20 * 2**20:
                        reasons.append('independent physical IO above 20 MiB/s')
                    raw = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True, timeout=15)
                    gpu_pids = [int(x.strip()) for x in raw.splitlines() if x.strip()]
                    if any(pid not in own for pid in gpu_pids):
                        reasons.append('independent GPU compute process')
                    disk = 0
                    for line in Path('/proc/diskstats').read_text().splitlines():
                        f = line.split()
                        if f[2].startswith('nvme') and 'p' not in f[2]:
                            disk += (int(f[5]) + int(f[9])) * 512
                    disk_delta = max(0, disk - old_disk) if old_disk is not None else 0
                    global_quiet = old_disk is not None and interval > .5 and disk_delta / interval <= 20 * 2**20
                    self.quiet_samples = self.quiet_samples + 1 if global_quiet and not reasons else 0
                    row = {'time': time.time(), 'interval_s': interval, 'phase': 'engine' if self.process else 'preflight', 'independent_cpu_ms': total_cpu, 'independent_physical_io_bytes': total_io, 'global_nvme_io_bytes': disk_delta, 'quiet_preflight_samples': self.quiet_samples, 'independent_processes': active, 'gpu_process_count': len(gpu_pids), 'only_our_gpu_processes': all(pid in own for pid in gpu_pids), 'contention_reasons': sorted(set(reasons))}
                    stream.write(json.dumps(row) + '\n')
                    stream.flush()
                    self.samples += 1
                    previous, last_time, old_disk = current, now, disk
                    if reasons:
                        self.failure = '; '.join(sorted(set(reasons)))
                        if self.process and self.process.poll() is None:
                            os.killpg(self.process.pid, signal.SIGTERM)
                        return
                except Exception as error:
                    self.failure = 'Host audit failed: ' + repr(error)
                    if self.process and self.process.poll() is None:
                        os.killpg(self.process.pid, signal.SIGTERM)
                    return
                self.stop.wait(2)

    def start(self):
        self.thread.start()
        for _ in range(300):
            if self.failure:
                raise RuntimeError(self.failure)
            if self.samples >= 4 and self.quiet_samples >= 3:
                return
            time.sleep(.1)
        raise RuntimeError('Insufficient host preflight samples')

    def attach(self, process):
        self.process = process
        if self.failure:
            os.killpg(process.pid, signal.SIGTERM)
            raise RuntimeError(self.failure)

    def close(self):
        self.stop.set()
        self.thread.join(timeout=20)
