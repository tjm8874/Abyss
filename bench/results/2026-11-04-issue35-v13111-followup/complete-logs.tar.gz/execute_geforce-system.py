"""Pinned, isolated follow-up; stop only the two approved idle user services."""
from pathlib import Path
import fcntl, hashlib, json, os, signal, subprocess, sys, time, traceback

R=Path(__file__).resolve().parent
OLD=Path('<workdir>')
PIN='5e8b9c44fec443fd1d0c9140885c47973f7970b4'
UNITS=['gpu-service-A','gpu-service-B']

def save(n,x): (R/n).write_text(json.dumps(x,indent=2)+'\n')
def call(a,check=True):
    return subprocess.run(a,capture_output=True,text=True,check=check)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot():
    return {u:call(['systemctl','--user','show',u,'--property=Id,ActiveState,SubState,MainPID']).stdout for u in UNITS}
def gpu():
    return call(['nvidia-smi','--query-gpu=index,name,temperature.gpu,memory.used,utilization.gpu,power.limit,pcie.link.gen.current,pcie.link.width.current','--format=csv,noheader,nounits']).stdout
def pid_ticks(pid):
    fields=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
    return int(fields[11])+int(fields[12])

lock=Path('<home>/abyss-gpu.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
before=snapshot();active=[u for u in UNITS if call(['systemctl','--user','is-active',u],False).stdout.strip()=='active']
save('services-before-benchmark.json',before)
pids={int(call(['systemctl','--user','show',u,'--property=MainPID','--value']).stdout) for u in active}
previous={p:pid_ticks(p) for p in pids};last=time.monotonic();idle=[]
for _ in range(5):
    time.sleep(2)
    now=time.monotonic();ticks={p:pid_ticks(p) for p in pids}
    raw=gpu();rows=[x.split(',') for x in raw.splitlines()]
    apps=call(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader']).stdout
    apps={int(x.strip()) for x in apps.splitlines() if x.strip()}
    cores=sum(ticks[p]-previous[p] for p in pids)/os.sysconf('SC_CLK_TCK')/(now-last)
    idle.append({'time':time.time(),'gpu':raw,'service_cpu_cores':cores,'apps_only_services':apps<=pids})
    assert apps<=pids and cores<.20 and all(float(x[4])<=5 for x in rows),'Services or another GPU task active; do not interrupt'
    previous,last=ticks,now
save('services-idle-proof.json',idle)
def interrupted(*_): raise KeyboardInterrupt('our follow-up interrupted')
signal.signal(signal.SIGTERM,interrupted)
try:
    if active: call(['systemctl','--user','stop',*active])
    for u in active: assert call(['systemctl','--user','is-active',u],False).stdout.strip()!='active'
    print('SERVICES_IDLE_STOPPED',flush=True)
    sys.path.insert(0,str(R))
    from host_audit import HostAudit
    from search_runner import Monitor
    d=R/'build-preflight';d.mkdir(exist_ok=True)
    audit=HostAudit(d);process=None
    try:
        audit.start()
        source=R/'source'
        if not source.exists(): call(['git','clone','--depth','1','--branch','v1.3.111','https://github.com/zephel01/Abyss.git',str(source)])
        assert call(['git','-C',str(source),'rev-parse','HEAD']).stdout.strip()==PIN
        assert not call(['git','-C',str(source),'status','--porcelain']).stdout.strip()
        assert (source/'VERSION').read_text().strip()=='1.3.111'
        assert call(['git','-C',str(OLD/'llama.cpp'),'rev-parse','HEAD']).stdout.strip()=='3cf03257f219afbe7334045ff7c6a06ac68c627d'
        commands=[['<toolchain-root>/.venv/bin/cmake','-S',str(source),'-B',str(R/'build'),'-G','Ninja','-DCMAKE_MAKE_PROGRAM=<toolchain-root>/.venv/bin/ninja','-DSTRATA_ENABLE_CUDA=ON','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CUDA_COMPILER=<cuda-toolkit>/bin/nvcc','-DCMAKE_CUDA_ARCHITECTURES=120a','-DSTRATA_BUILD_TESTS=OFF','-DSTRATA_GGML_DIR='+str(OLD/'llama.cpp')],['<toolchain-root>/.venv/bin/cmake','--build',str(R/'build'),'--target','strata','-j4']]
        save('build-commands.json',commands)
        with (R/'build.log').open('w') as out:
            for args in commands:
                process=subprocess.Popen(args,stdout=out,stderr=subprocess.STDOUT,start_new_session=True);audit.attach(process)
                with Monitor(d,process) as mon:
                    process.wait(1800)
                    if process.returncode or audit.failure or mon.failure: raise RuntimeError((process.returncode,audit.failure,mon.failure))
        save('build-provenance.json',{'version':'1.3.111','commit':PIN,'binary_sha256':sha(R/'build/strata'),'ggml_commit':'3cf03257f219afbe7334045ff7c6a06ac68c627d','clean_source':not call(['git','-C',str(source),'status','--porcelain']).stdout.strip(),'finished_at':time.time()})
    finally:
        if process is not None and process.poll() is None:
            os.killpg(process.pid,signal.SIGTERM);process.wait(30)
        audit.close()
    print('BUILD_COMPLETE',flush=True)
    (R/'model/pack').mkdir(parents=True,exist_ok=True)
    for f in (OLD/'model').glob('*.gguf'):
        if not (R/'model'/f.name).exists(): (R/'model'/f.name).symlink_to(f.resolve())
    import shutil
    for f in (OLD/'model/pack').iterdir():
        target=R/'model/pack'/f.name
        if target.exists():continue
        if f.is_symlink():target.symlink_to(f.resolve(),target_is_directory=f.is_dir())
        else:shutil.copyfile(f,target)
    if not (R/'mtp').exists():(R/'mtp').symlink_to((OLD/'mtp').resolve(),target_is_directory=True)
    files=list((R/'model').glob('*.gguf'))+[R/'model/pack'/n for n in ['dense.bin','index.txt','native_experts.txt']]+list((R/'mtp').iterdir())
    stamps={str(f.resolve()):[f.stat().st_size,f.stat().st_mtime_ns] for f in files}
    save('model-preservation-before.json',stamps)
    from search_runner import run_case
    fixtures=json.loads((R/'fixtures.json').read_text())
    plan=json.loads((R/'server-plan.json').read_text())
    results=[]
    for cfg in plan['cases']:
        requests=cfg.get('requests',plan['requests'])
        fs=[]
        for req in requests:
            f=dict(next(f for f in fixtures if f['name']==req['fixture']));f['cap']=req['cap'];fs.append(f)
        try:
            rows=run_case(cfg,fs);results.append({'case':cfg['name'],'status':'complete','rows':len(rows)})
        except Exception as e:
            results.append({'case':cfg['name'],'status':'failed','error':repr(e)})
            if cfg.get('allow_resource_limited_failure') and not any('contention_reasons": ["' in p.read_text() for p in (R/'runs'/cfg['name']).glob('host-activity.jsonl')):
                print('LIMITED_CASE_FAILURE '+cfg['name']+' '+repr(e),flush=True)
            else:raise
        save('case-summary.json',results)
    after={str(f.resolve()):[f.stat().st_size,f.stat().st_mtime_ns] for f in files}
    assert stamps==after
    save('model-preservation-after.json',{'same_size_mtime':True,'files':after,'metadata_sha256':{f.name:sha(f) for f in [R/'model/pack/index.txt',R/'model/pack/native_experts.txt',R/'mtp/dense.txt',R/'source/data/expert_counts/qwen38-flash-next.txt']}})
    print('TARGETED_CASES_COMPLETE',flush=True)
except BaseException as e:
    save('execution-failure.json',{'error':repr(e),'traceback':traceback.format_exc(),'time':time.time()})
    raise
finally:
    if active: call(['systemctl','--user','start',*active])
    restored=all(call(['systemctl','--user','is-active',u],False).stdout.strip()=='active' for u in active)
    save('services-restored.json',{'before':before,'after':snapshot(),'prior_active':active,'restored':restored,'time':time.time(),'gpu_after':gpu(),'gpu_apps':call(['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader,nounits']).stdout})
    print('SERVICES_RESTORED '+str(restored),flush=True)
    assert restored
