"""A stricter first budget forces the auto one-card fallback; same approved service guard."""
from pathlib import Path
import fcntl,json,os,signal,subprocess,time
from search_runner import run_case
R=Path(__file__).resolve().parent
units=['gpu-service-A','gpu-service-B']
def call(a):return subprocess.run(a,capture_output=True,text=True)
def snapshot():return {u:call(['systemctl','--user','show',u,'--property=Id,ActiveState,SubState,MainPID']).stdout for u in units}
def ticks(p):
 f=Path(f'/proc/{p}/stat').read_text().rsplit(')',1)[1].split();return int(f[11])+int(f[12])
lock=Path('<home>/abyss-gpu.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
before=snapshot();active=[u for u in units if call(['systemctl','--user','is-active',u]).stdout.strip()=='active']
pids={int(call(['systemctl','--user','show',u,'--property=MainPID','--value']).stdout) for u in active}
prev={p:ticks(p) for p in pids};last=time.monotonic();idle=[]
for _ in range(5):
 time.sleep(2);now=time.monotonic();cur={p:ticks(p) for p in pids}
 raw=call(['nvidia-smi','--query-gpu=utilization.gpu','--format=csv,noheader,nounits']).stdout
 apps={int(x) for x in call(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader']).stdout.splitlines() if x.strip()}
 cpu=sum(cur[p]-prev[p] for p in pids)/os.sysconf('SC_CLK_TCK')/(now-last)
 assert apps<=pids and cpu<.2 and all(float(x)<=5 for x in raw.splitlines()),'Busy service; do not stop'
 idle.append({'time':time.time(),'service_cpu_cores':cpu,'apps_only_services':True,'gpu_util':raw});prev,last=cur,now
(R/'supplement-service-idle.json').write_text(json.dumps(idle,indent=2))
def interrupt(*_):raise KeyboardInterrupt('supplement interrupted')
signal.signal(signal.SIGTERM,interrupt)
try:
 if active:subprocess.run(['systemctl','--user','stop',*active],check=True)
 plan=json.loads((R/'resume-plan.json').read_text());fixtures=json.loads((R/'fixtures.json').read_text())
 for cfg in plan['cases']:
  fs=[]
  for req in cfg.get('requests',plan['requests']):
   f=dict(next(f for f in fixtures if f['name']==req['fixture']));f['cap']=req['cap'];fs.append(f)
  run_case(cfg,fs)
finally:
 if active:subprocess.run(['systemctl','--user','start',*active],check=True)
 restored=all(call(['systemctl','--user','is-active',u]).stdout.strip()=='active' for u in active)
 (R/'supplement-services-restored.json').write_text(json.dumps({'before':before,'after':snapshot(),'restored':restored,'prior_active':active,'time':time.time(),'gpu_apps':call(['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader,nounits']).stdout},indent=2))
 print('SUPPLEMENT_SERVICES_RESTORED '+str(restored),flush=True)
 assert restored
