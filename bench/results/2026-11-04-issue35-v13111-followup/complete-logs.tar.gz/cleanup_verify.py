from pathlib import Path
import fcntl,hashlib,json,subprocess,time
R=Path(__file__).resolve().parent
lock=Path('<home>/abyss-gpu.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
def call(a):return subprocess.check_output(a,text=True)
own=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if (p/'cmdline').read_bytes().split(b'\0')[0].decode()==str(R/'build/strata'):own.append(int(p.name))
 except (OSError,UnicodeDecodeError):pass
assert not own
units=['gpu-service-A','gpu-service-B']
services={u:call(['systemctl','--user','show',u,'--property=Id,ActiveState,SubState,MainPID']) for u in units}
assert all('ActiveState=active' in v for v in services.values())
pids={int(call(['systemctl','--user','show',u,'--property=MainPID','--value'])) for u in units}
for _ in range(30):
 apps=call(['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader,nounits'])
 gpids={int(l.split(',')[0]) for l in apps.splitlines() if l.strip()}
 if pids<=gpids:break
 time.sleep(1)
assert pids<=gpids,'Restored services GPU reservations not yet visible'
before=json.loads((R/'model-preservation-before.json').read_text())
after={name:[Path(name).stat().st_size,Path(name).stat().st_mtime_ns] for name in before}
assert before==after
metadata=[R/'model/pack/index.txt',R/'model/pack/native_experts.txt',R/'mtp/dense.txt',R/'source/data/expert_counts/qwen38-flash-next.txt']
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in metadata}
binary=hashlib.sha256((R/'build/strata').read_bytes()).hexdigest()
assert binary==json.loads((R/'build-provenance.json').read_text())['binary_sha256']
clean=call(['git','-C',str(R/'source'),'status','--porcelain']);assert not clean.strip()
proof={'time':time.time(),'own_engine_processes':own,'shared_lock_free':True,'lock_note':'Nonblocking acquisition after benchmark exit; released when this read-only verification process exits.','services_active':True,'services':services,'gpu_apps':apps,'gpu':call(['nvidia-smi','--query-gpu=index,name,memory.used,power.limit,temperature.gpu,pcie.link.gen.current,pcie.link.width.current','--format=csv,noheader,nounits']),'models_same_size_mtime':True,'model_files':after,'metadata_sha256':hashes,'binary_sha256':binary,'binary_matches_build':True,'source_clean':True,'source_commit':call(['git','-C',str(R/'source'),'rev-parse','HEAD']).strip(),'source_version':(R/'source/VERSION').read_text().strip(),'policy':'No original model/config or power/clock/fan policy writes; only the two approved idle user services were stopped and restored.'}
(R/'cleanup-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
(R/'model-preservation-after.json').write_text(json.dumps({'same_size_mtime':True,'files':after,'metadata_sha256':hashes},indent=2)+'\n')
print('Verified original model size/mtime, metadata/binary hashes, clean source, both services and GPU reservations, no own engines and free lock.')
