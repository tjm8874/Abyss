from pathlib import Path
import json

# Reuse the exact dispatch/resource guard with only the profiler variable omitted.
HERE = Path(__file__).resolve().parent
code = (HERE / 'run_profile.py').read_text().split('def main():')[0]
needle = "'STRATA_GLM_PREFILL_PROF': '1', "
assert code.count(needle) == 1
exec(compile(code.replace(needle, ''), str(HERE / 'run_profile.py') + ':profiler-omitted', 'exec'), globals())

def main():
    results = json.loads((ROOT / 'results.json').read_text())
    triggered = len(results['cases']) == 6 and not results['pair_found'] and all(c['classification'] == 'slow' for c in results['cases'])
    save(ROOT / 'control-decision.json', {'triggered': triggered, 'profiled_processes': len(results['cases']), 'reason': 'Two uninstrumented controls only if all six profiled processes were slow.'})
    if not triggered:
        print('Conditional controls not triggered', flush=True)
        return
    lock = Path('<HOME>/abyss-gpu.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not command(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader']).strip()
    assert not (ROOT / 'control-before.json').exists()
    before = snapshot()
    save(ROOT / 'control-before.json', before)
    save(ROOT / 'profile-status.json', json.loads((ROOT / 'status.json').read_text()))
    fixtures = json.loads((ROOT / 'fixtures.json').read_text())['identical']
    controls = []
    try:
        for attempt in [1, 2]:
            name = f'no-prof-{attempt:02d}'
            rows = run_case(name, True, fixtures, resync=0, pause_s=0.0, purpose='unprofiled_control')
            settings = json.loads((ROOT / 'runs' / name / 'settings.json').read_text())
            assert 'STRATA_GLM_PREFILL_PROF' not in settings['environment']
            log = (ROOT / 'runs' / name / 'engine.stderr.log').read_text()
            helper = [s for s in log.splitlines() if s.startswith('expert helper request_end:')]
            assert len(helper) == 3 and all('fallbacks 0' in s for s in helper)
            assert 'glm prefill prof CUDA' not in log and 'CPU fallback' not in log
            classification = 'slow' if all(r['prefill_tps'] < 2300 for r in rows) else 'fast' if all(r['prefill_tps'] > 2500 for r in rows) else 'mixed_or_intermediate'
            controls.append({'case': name, 'classification': classification, 'rows': [{k:v for k,v in r.items() if k != 'output_ids'} for r in rows], 'profiler_absent': True})
            save(ROOT / 'controls.json', controls)
            status('control_complete', case=name, classification=classification)
        status('complete', profiled_processes=6, unprofiled_controls=2, pair_found=False)
    except BaseException as error:
        save(ROOT / 'control-failure.json', {'error': repr(error), 'time': time.time()})
        status('failed', error=repr(error))
        raise
    finally:
        after = snapshot()
        save(ROOT / 'control-after.json', after)
        assert before['small_sha256'] == after['small_sha256'] and before['model_stats'] == after['model_stats']
        save(ROOT / 'control-preservation.json', {'source_pack_hashes_unchanged': True, 'model_sizes_and_mtimes_unchanged': True, 'running_user_services_unchanged': before['services'] == after['services'], 'gpu_compute_apps_after': command(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader']).strip()})

if __name__ == '__main__':
    def interrupted(signum, _frame):
        raise SystemExit('Interrupted by signal ' + str(signum))
    for signum in [signal.SIGTERM, signal.SIGINT, signal.SIGHUP]:
        signal.signal(signum, interrupted)
    main()
