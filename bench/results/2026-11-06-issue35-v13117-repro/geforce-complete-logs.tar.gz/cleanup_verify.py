from pathlib import Path
import fcntl,hashlib,json,subprocess,time
R=Path(__file__).resolve().parent
def call(a):return subprocess.check_output(a,text=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
lock=Path('<home>/abyss-gpu.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
own=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  args=(p/'cmdline').read_bytes().split(b'\0')
  if args and args[0].decode()==str(R/'build/strata'):own.append(int(p.name))
 except (OSError,UnicodeDecodeError):pass
assert not own
units=['gpu-service-A','gpu-service-B']
services={u:call(['systemctl','--user','show',u,'--property=Id,ActiveState,SubState,MainPID']) for u in units}
prior=json.loads((R/'services-before.json').read_text())
assert all(('ActiveState=active' in prior[u])==('ActiveState=active' in services[u]) for u in units)
pids={int(call(['systemctl','--user','show',u,'--property=MainPID','--value'])) for u in units if 'ActiveState=active' in prior[u]}
for _ in range(30):
 apps=call(['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader,nounits'])
 gpids={int(l.split(',')[0]) for l in apps.splitlines() if l.strip()}
 if pids<=gpids:break
 time.sleep(1)
assert pids<=gpids
before=json.loads((R/'model-preservation-before.json').read_text())
after={name:[Path(name).stat().st_size,Path(name).stat().st_mtime_ns] for name in before}
assert before==after
metadata=[R/'model/pack/index.txt',R/'model/pack/native_experts.txt',R/'mtp/dense.txt',R/'source/data/expert_counts/qwen38-flash-next.txt']
hashes={str(p):sha(p) for p in metadata}
binary=sha(R/'build/strata');prov=json.loads((R/'build-provenance.json').read_text())['versions']['117']
assert binary==prov['binary_sha256']
assert not call(['git','-C',str(R/'source'),'status','--porcelain']).strip()
assert call(['git','-C',str(R/'source'),'rev-parse','HEAD']).strip()=='8d1cb8adfe42c8f8ceaf7e910ec69467754b7178'
proof={'time':time.time(),'own_engine_processes':own,'shared_lock_free':True,'lock_note':'Nonblocking acquisition after master exit; released when verification exits.','services_prior_state_restored':True,'services':services,'gpu_apps':apps,'gpu':call(['nvidia-smi','--query-gpu=index,name,memory.used,power.limit,temperature.gpu,pcie.link.gen.current,pcie.link.width.current','--format=csv,noheader,nounits']),'models_same_size_mtime':True,'model_files':after,'metadata_sha256':hashes,'binary_sha256':binary,'binary_matches_build':True,'source_clean':True,'source_commit':prov['commit'],'source_version':(R/'source/VERSION').read_text().strip(),'policy':'Only the two approved idle user services were temporarily stopped/restored. No originalmodel/config/power/clock/fan/OSupdater change.'}
(R/'cleanup-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print('Verified prior services and GPU reservations, own engine exit, lock release, model preservation and clean pinned source/binary.')
