"""Isolated v117 numerical diagnostics, exclusive per host, with guarded service restoration."""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,signal,subprocess,sys,time,traceback,urllib.request
R=Path(__file__).resolve().parent
HOST=sys.argv[1];assert HOST=='geforce-system'
OLD=Path('<v109-workdir>')
PREV=Path('<v111-workdir>')
PINS={117:'8d1cb8adfe42c8f8ceaf7e910ec69467754b7178'}
def save(name,x):(R/name).write_text(json.dumps(x,indent=2)+'\n')
def call(a,check=True):return subprocess.run(a,capture_output=True,text=True,check=check)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def properties(u):return call(['systemctl','--user','show',u,'--property=Id,ActiveState,SubState,MainPID']).stdout
def queues(units):
 out={};opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
 for u in units:
  pid=int(call(['systemctl','--user','show',u,'--property=MainPID','--value']).stdout)
  a=Path(f'/proc/{pid}/cmdline').read_bytes().decode().split('\0')
  host=a[a.index('--listen')+1] if '--listen' in a else '127.0.0.1';host='127.0.0.1' if host in ['0.0.0.0','::'] else host
  port=a[a.index('--port')+1] if '--port' in a else '8188'
  q=json.load(opener.open('http://'+host+':'+port+'/queue',timeout=4))
  out[u]={'running':len(q['queue_running']),'pending':len(q['queue_pending'])}
  assert not q['queue_running'] and not q['queue_pending'],'Queued or active other work; do not stop service'
 return out
def ticks(pid):
 f=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split();return int(f[11])+int(f[12])
lock=Path('<home>/abyss-gpu.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
units=['gpu-service-A','gpu-service-B'] if HOST=='geforce-system' else []
before={u:properties(u) for u in units};active=[u for u in units if call(['systemctl','--user','is-active',u],False).stdout.strip()=='active']
save('services-before-single.json',before)
if active:
 q=queues(active);pids={int(call(['systemctl','--user','show',u,'--property=MainPID','--value']).stdout) for u in active};last=time.monotonic();prev={p:ticks(p) for p in pids};idle=[]
 for _ in range(5):
  time.sleep(2);now=time.monotonic();cur={p:ticks(p) for p in pids}
  gpu=call(['nvidia-smi','--query-gpu=index,utilization.gpu,memory.used','--format=csv,noheader,nounits']).stdout
  apps={int(x) for x in call(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader']).stdout.splitlines() if x.strip()}
  cpu=sum(cur[p]-prev[p] for p in pids)/os.sysconf('SC_CLK_TCK')/(now-last)
  assert apps<=pids and cpu<.2 and all(float(l.split(',')[1])<=5 for l in gpu.splitlines()),'Service or independent GPU work active'
  idle.append({'time':time.time(),'gpu':gpu,'service_cpu_cores':cpu,'apps_only_services':True});prev,last=cur,now
 save('services-idle-proof-single.json',{'first_queues':q,'final_queues':queues(active),'samples':idle})
def interrupted(*_):raise KeyboardInterrupt('Our paired benchmark interrupted')
signal.signal(signal.SIGTERM,interrupted)
try:
 if active:call(['systemctl','--user','stop',*active])
 for u in active:assert call(['systemctl','--user','is-active',u],False).stdout.strip()!='active'
 from host_audit import HostAudit
 from search_runner import Monitor,run_case
 save('inventory-single.json',{k:call(a).stdout for k,a in {'gpu':['nvidia-smi','--query-gpu=index,name,memory.total,driver_version,power.limit,pcie.link.gen.max,pcie.link.width.max','--format=csv,noheader,nounits'],'kernel':['uname','-r'],'cpu':['lscpu'],'mem':['free','-b'],'mount':['findmnt','-T',str(OLD/'model'),'--output','TARGET,SOURCE,FSTYPE'],'disk':['df','-h',str(R)]}.items()})
 prov=json.loads((R/'build-provenance.json').read_text())['versions']['117']
 assert sha(R/'build/strata')==prov['binary_sha256']
 assert call(['git','-C',str(R/'source'),'rev-parse','HEAD']).stdout.strip()==PINS[117]
 assert not call(['git','-C',str(R/'source'),'status','--porcelain']).stdout.strip()
 assert sha(R/'source/data/expert_counts/qwen38-flash-next.txt')=='d62f4f0da4e8de44e05fdac38e9965855df12d64f6d21df29d05bdfc246ed721'
 save('single-binary-provenance.json',prov)
 files=list((R/'model').glob('*.gguf'))+[R/'model/pack'/n for n in ['dense.bin','index.txt','native_experts.txt']]+list((R/'mtp').iterdir())
 stamps={str(p.resolve()):[p.stat().st_size,p.stat().st_mtime_ns] for p in files};save('model-preservation-before-single.json',stamps)
 plan=json.loads((R/'single-plan.json').read_text());fixtures=json.loads((R/'fixtures.json').read_text());summary=[]
 for cfg in plan['cases']:
  if (R/'runs'/cfg['name']/'result.json').exists():continue
  fs=[]
  for req in cfg.get('requests',plan['requests']):
   f=dict(next(f for f in fixtures if f['name']==req['fixture']));f['cap']=req['cap'];fs.append(f)
  rows=run_case(cfg,fs);summary.append({'case':cfg['name'],'status':'complete','requests':len(rows)});save('diagnostic-case-summary-single.json',summary)
 print('DIAGNOSTIC_CASES_COMPLETE',flush=True)
 after={str(p.resolve()):[p.stat().st_size,p.stat().st_mtime_ns] for p in files};assert stamps==after
 metadata=[R/'model/pack/index.txt',R/'model/pack/native_experts.txt',R/'mtp/dense.txt',R/'source/data/expert_counts/qwen38-flash-next.txt']
 save('model-preservation-after-single.json',{'same_size_mtime':True,'files':after,'metadata_sha256':{p.name:sha(p) for p in metadata}})
 save('execution-complete-single.json',{'time':time.time(),'diagnostic_processes':len(plan['cases']),'diagnostic_only':True})
except BaseException as e:
 save('execution-failure-single.json',{'error':repr(e),'traceback':traceback.format_exc(),'time':time.time()});raise
finally:
 if active:call(['systemctl','--user','start',*active])
 restored=all(call(['systemctl','--user','is-active',u],False).stdout.strip()=='active' for u in active)
 save('services-restored-single.json',{'before':before,'after':{u:properties(u) for u in units},'prior_active':active,'restored':restored,'time':time.time()})
 print('SERVICES_RESTORED '+str(restored),flush=True)
 assert restored
