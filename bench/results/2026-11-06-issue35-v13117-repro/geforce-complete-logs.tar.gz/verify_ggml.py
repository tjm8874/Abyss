from pathlib import Path
import json,subprocess,time
r=Path(__file__).resolve().parent;g=Path('<v109-workdir>/llama.cpp')
def call(a):return subprocess.check_output(a,text=True).strip()
expected={'ggml/src/ggml.c':'1752814093b5cf973a820794e0dbe53fb8c6fe5b','ggml/src/ggml-quants.c':'1ebc50a763f16db909de37090da38cc8c0fdde94','ggml/src/ggml-cpu/ggml-cpu.c':'8bb0ff7bc3366be957dd20aba3fbe0f50dd249d7','ggml/src/ggml-cuda/mmq.cuh':'6923f3510c03c2d04fda508aae5c9208014fb12e'}
head=call(['git','-C',str(g),'rev-parse','HEAD']);status=call(['git','-C',str(g),'status','--porcelain']);assert head=='3cf03257f219afbe7334045ff7c6a06ac68c627d' and not status
actual={name:call(['git','-C',str(g),'hash-object',str(g/name)]) for name in expected};assert actual==expected
(r/'ggml-source-verification.json').write_text(json.dumps({'time':time.time(),'head':head,'tracked_worktree_clean':True,'git_blob_sha1':actual,'all_four_match_prior_primary_source':True,'scope':'Small source hashes after diagnostics; no model hashing during any request.'},indent=2)+'\n')
print('Verified clean GGML HEAD and four source blobs after diagnostics.')
