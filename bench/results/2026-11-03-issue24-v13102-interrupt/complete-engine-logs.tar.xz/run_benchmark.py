#!/usr/bin/env python3
"""Issue #24: v1.3.102: author-requested immediate-next-request resync interruption smoke.

Only creates files under ROOT; never stops, starts, or changes any service.
"""
from pathlib import Path
import fcntl
import hashlib
import json
import os
import queue
import re
import signal
import statistics
import subprocess
import threading
import time

ROOT = Path('<HOME>/abyss-issue24-v13102-20261103')
EXE = ROOT / 'build/strata'
OLD = Path('<HOME>/abyss-iq2xs-huihui-mxfp8-20261030')
PACK_SOURCE = OLD / 'pro5000/pack'
VIEW = Path('<HOME>/Strata-data/models/DeepSeek-V4.1-Flash-1017-IQ2_XS-Huihui-MXFP8-view')
DRAFTER = Path('<HOME>/dspark-v41-Q2K-Q4K.gguf')


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def command(args):
    return subprocess.run(args, text=True, capture_output=True, check=True, timeout=30).stdout


def status(phase, **kwargs):
    row = {'phase': phase, 'time': time.time(), **kwargs}
    save(ROOT / 'status.json', row)
    print(json.dumps(row), flush=True)


def memory_snapshot(pid):
    result = {}
    for label, path in [('system', Path('/proc/meminfo')), ('engine', Path('/proc') / str(pid) / 'smaps_rollup')]:
        values = {}
        for line in path.read_text().splitlines():
            if ':' not in line:
                continue
            key, rest = line.split(':', 1)
            parts = rest.strip().split()
            if parts and parts[0].isdigit():
                values[key] = int(parts[0]) * (1024 if parts[1:] == ['kB'] else 1)
        result[label] = values
    return result


def snapshot():
    small = [PACK_SOURCE / name for name in ['index.txt', 'native_experts.txt', 'engram.txt']]
    sources = [p.resolve() for p in VIEW.glob('*.gguf')]
    sources += [Path('<HOME>/Strata-data/models/DeepSeek-V4.1-Flash-1017-Engram-MXFP8/DeepSeek-V4.1-Flash-Engram-MXFP8.gguf'), DRAFTER.resolve()]
    return {
        'time': time.time(),
        'gpu': command(['nvidia-smi', '--query-gpu=index,name,pci.bus_id,memory.used,temperature.gpu,driver_version,pcie.link.gen.current,pcie.link.width.current', '--format=csv']),
        'services': subprocess.run(['systemctl', '--user', 'list-units', '--type=service', '--state=running', '--no-pager'], text=True, capture_output=True).stdout,
        'small_sha256': {str(p): digest(p) for p in small},
        'model_stats': {str(p): {'bytes': p.stat().st_size, 'mtime_ns': p.stat().st_mtime_ns} for p in sources},
    }


class Monitor:
    def __init__(self, directory, process):
        self.directory, self.process = directory, process
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self.loop, daemon=True)
        self.failure = None

    def loop(self):
        with (self.directory / 'telemetry.jsonl').open('w') as stream:
            while not self.stop.is_set():
                try:
                    raw = command(['nvidia-smi', '--query-gpu=index,temperature.gpu,memory.used,utilization.gpu,pcie.link.gen.current,pcie.link.width.current,clocks_event_reasons.hw_thermal_slowdown,clocks_event_reasons.sw_thermal_slowdown,power.draw,clocks.sm,clocks.mem', '--format=csv,noheader,nounits'])
                    gpus = []
                    for line in raw.splitlines():
                        fields = [x.strip() for x in line.split(',')]
                        keys = ['index', 'temperature_c', 'memory_mib', 'util_percent', 'pcie_gen', 'pcie_width', 'hw_thermal', 'sw_thermal', 'power_w', 'sm_clock_mhz', 'memory_clock_mhz']
                        gpus.append(dict(zip(keys, fields)))
                    mem = {}
                    for line in Path('/proc/meminfo').read_text().splitlines():
                        key, value = line.split(':', 1)
                        mem[key] = int(value.strip().split()[0]) * 1024
                    row = {'time': time.time(), 'gpus': gpus, 'available_bytes': mem['MemAvailable'], 'swap_used_bytes': mem['SwapTotal'] - mem['SwapFree']}
                    stream.write(json.dumps(row) + '\n')
                    stream.flush()
                    hot = any(float(g['temperature_c']) >= (85 if g['index'] == '0' else 90) or g['hw_thermal'].lower() == 'active' or g['sw_thermal'].lower() == 'active' for g in gpus)
                    if hot or row['available_bytes'] < 6 * 2**30 or row['swap_used_bytes'] > 2**30:
                        self.failure = 'Temperature, thermal slowdown, or RAM/swap limit'
                        save(self.directory / 'resource-guard.json', row)
                        os.killpg(self.process.pid, signal.SIGTERM)
                        return
                except Exception as error:
                    self.failure = 'Telemetry failed: ' + repr(error)
                    os.killpg(self.process.pid, signal.SIGTERM)
                    return
                self.stop.wait(2)

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, *_):
        self.stop.set()
        self.thread.join(timeout=35)


def run_case(name, helper, fixtures, check=False, resync=0, pause_s=5.0, purpose="performance"):
    assert not command(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader']).strip(), 'GPUs in use between cases'
    directory = ROOT / 'runs' / name
    directory.mkdir(parents=True, exist_ok=False)
    env = {k: v for k, v in os.environ.items() if not k.startswith(('STRATA_', 'DS4_', 'MAYA_', 'ABYSS_', 'CUDA_'))}
    selected = {
        'CUDA_DEVICE_ORDER': 'PCI_BUS_ID', 'CUDA_VISIBLE_DEVICES': '1,0',
        'STRATA_GLM_SPLIT': '0', 'STRATA_GLM_EXPERT_HELPER': '1' if helper else '0',
        'STRATA_GLM_EXPERT_HELPER_GIB': '28', 'STRATA_GLM_EXPERT_HELPER_PROMOTE': '0',
        'STRATA_GLM_EXPERT_HELPER_RESYNC': str(resync),
        'STRATA_GLM_RAM_GB': '119.20928955078125', 'STRATA_GLM_CPU_LANE': '12',
        'STRATA_GLM_NO_SPEC': '1', 'STRATA_DS4_SPEC': '1', 'STRATA_DS4_DSPARK': str(DRAFTER),
        'STRATA_GLM_NO_REUSE': '1', 'STRATA_GLM_USAGE': '0', 'STRATA_GLM_KDA_GRAPH': '0',
        'STRATA_GLM_TAIL_SKIP': '0', 'STRATA_GLM_TAIL_SKIP_W': '0',
        'STRATA_GLM_TAIL_SKIP_DISK': '0', 'STRATA_GLM_PREFILL_TAIL_SKIP': '0',
    }
    if check:
        selected['STRATA_GLM_EXPERT_HELPER_CHECK'] = '1'
    env.update(selected, LD_LIBRARY_PATH='/usr/local/cuda-13.0/lib64')
    args = [str(EXE), '--serve', '--glm-pack', str(ROOT / 'model/pack'), '--max-context', '32768', '--prefill', '4096', '--spec', '5', '--layer-split', '0']
    save(directory / 'settings.json', {'command': args, 'environment': selected, 'check_run_excluded_from_performance': check, 'purpose': purpose, 'excluded_from_primary_performance': purpose != 'performance', 'requested_pause_s': pause_s,
         'dispatch': 'Send the next pre-encoded GEN immediately after DONE, before parsing/saving metrics. Request timer starts before write/flush. Final resync completes before QUIT is sent.'})
    events, stdout_lines, threads = queue.Queue(), [], []
    resync_completions = queue.Queue()
    proc = None
    started = time.monotonic()
    def next_event(deadline):
        try:
            now, line = events.get(timeout=max(.01, deadline - time.monotonic()))
        except queue.Empty:
            raise TimeoutError('Native engine deadline exceeded')
        if line is None or line.startswith('ERR'):
            raise RuntimeError('Engine ended: ' + str(line))
        return now, line
    try:
        proc = subprocess.Popen(args, cwd=directory, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, text=True, bufsize=1, start_new_session=True)
        def read_stdout():
            with (directory / 'protocol-timeline.jsonl').open('w') as timeline:
                for line in proc.stdout:
                    now = time.monotonic()
                    stdout_lines.append(line)
                    if not line.startswith('T '):
                        timeline.write(json.dumps({'elapsed_s': now - started, 'line': line.rstrip()}) + '\n')
                        if line.startswith(('PP ', 'DONE ', 'READY ')):
                            timeline.flush()
                    events.put((now, line.rstrip()))
            events.put((time.monotonic(), None))
        def read_stderr():
            with (directory / 'engine.stderr.log').open('w') as log, (directory / 'stderr-timeline.jsonl').open('w') as timeline:
                for line in proc.stderr:
                    now = time.monotonic()
                    log.write(line)
                    log.flush()
                    timeline.write(json.dumps({'elapsed_s': now - started, 'line': line.rstrip()}) + '\n')
                    timeline.flush()
                    if re.fullmatch(r'expert helper resync: (\d+) promotions in ([\d.]+) ms(?: \(stopped: the next request\))? \(longest gap between next-request checks ([\d.]+) ms\)', line.rstrip()):
                        resync_completions.put((now, line.rstrip()))
        for fn in [read_stdout, read_stderr]:
            t = threading.Thread(target=fn, daemon=True)
            t.start()
            threads.append(t)
        with Monitor(directory, proc) as monitor:
            status('loading', case=name, engine_pid=proc.pid)
            while not next_event(started + 600)[1].startswith('READY '):
                pass
            commands = [f"GEN {f['cap']} temperature=0 top_p=1 top_k=0 min_p=0 seed=42 spec=1 cpu_threads=12 " + ','.join(map(str, f['ids'])) + '\n' for f in fixtures]
            sends, write_ms = {}, {}
            def dispatch(i):
                sends[i] = time.monotonic()
                proc.stdin.write(commands[i])
                proc.stdin.flush()
                write_ms[i] = (time.monotonic() - sends[i]) * 1000
            dispatch(0)
            rows, previous_done = [], None
            for i, fixture in enumerate(fixtures):
                status('request', case=name, fixture=fixture['name'], check=check)
                t0, first, tokens, progress = sends[i], None, [], []
                while True:
                    now, line = next_event(t0 + 600)
                    if line.startswith('T '):
                        first = now if first is None else first
                        tokens.append(int(line.split()[1]))
                    elif line.startswith('PP '):
                        progress.append({'client_elapsed_s': now - t0, 'line': line})
                    elif line.startswith('DONE '):
                        # Prioritize the next request over JSON, status and diagnostic I/O.
                        if i + 1 < len(fixtures):
                            time.sleep(max(0.0, now + pause_s - time.monotonic()))
                            dispatch(i + 1)
                        fields = line.split()
                        assert int(fields[1]) == len(tokens) == fixture['cap']
                        assert int(fields[2]) == len(fixture['ids']) == 16384
                        assert fields[5] == 'length' and int(fields[8]) == 0
                        assert int(fields[6]) > 0 and int(fields[7]) > 0, 'DSpark inactive'
                        pms, dms = float(fields[3]), float(fields[4])
                        row = {'case': name, 'name': fixture['name'], 'input_tokens': len(fixture['ids']), 'output_tokens': len(tokens),
                               'input_ids_sha256': fixture['sha256'], 'output_ids_sha256': hashlib.sha256(','.join(map(str, tokens)).encode()).hexdigest(),
                               'output_ids': tokens, 'prefill_tps': len(fixture['ids']) * 1000 / pms, 'decode_tps': len(tokens) * 1000 / dms,
                               'prefill_ms': pms, 'decode_ms': dms, 'ttft_s': first - t0, 'wall_s': now - t0,
                               'draft_accepted': int(fields[6]), 'draft_offered': int(fields[7]), 'reused': int(fields[8]), 'done': line,
                               'prompt_progress': progress, 'send_elapsed_s': t0 - started, 'done_elapsed_s': now - started,
                               'requested_pause_s': pause_s, 'purpose': purpose, 'dispatch_write_ms': write_ms[i], 'client_gap_since_previous_done_ms': None if previous_done is None else (t0 - previous_done) * 1000,
                               'wall_minus_native_ms': (now - t0) * 1000 - pms - dms}
                        save(directory / (fixture['name'] + '.json'), row)
                        rows.append(row)
                        previous_done = now
                        print(json.dumps({k: v for k, v in row.items() if k not in ['output_ids', 'prompt_progress']}), flush=True)
                        break
            # Wait for the final post-DONE resync as well; keep resource monitoring active.
            if resync:
                for _ in fixtures:
                    resync_completions.get(timeout=60)
            proc.stdin.write('QUIT\n')
            proc.stdin.flush()
            proc.wait(timeout=60)
            if proc.returncode:
                raise RuntimeError('Engine exit code ' + str(proc.returncode))
            if monitor.failure:
                raise RuntimeError(monitor.failure)
        return rows
    finally:
        if proc is not None and proc.poll() is None:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
        for t in threads:
            t.join(timeout=5)
        (directory / 'engine.stdout.log').write_text(''.join(stdout_lines))


def main():
    lock = Path('<HOME>/abyss-gpu.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert EXE.is_file()
    assert not (ROOT / 'before.json').exists(), 'Never overwrite a previous run'
    assert not command(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader']).strip(), 'GPUs already in use'
    before = snapshot()
    save(ROOT / 'before.json', before)
    original = json.loads((OLD / 'fixtures.json').read_text())[:3]
    assert [f['name'] for f in original] == ['warmup-01', 'trial-01', 'trial-02']
    for f in original:
        assert len(f['ids']) == 16384 and f['cap'] == 2048
        assert hashlib.sha256(','.join(map(str, f['ids'])).encode()).hexdigest() == f['sha256']
    identical = [{**original[1], 'name': f['name']} for f in original]
    families = {'original': original, 'identical': identical}
    save(ROOT / 'fixtures.json', families)
    model = ROOT / 'model'
    pack = model / 'pack'
    pack.mkdir(parents=True, exist_ok=False)
    for source in VIEW.glob('*.gguf'):
        (model / source.name).symlink_to(source.resolve())
    for source in PACK_SOURCE.iterdir():
        if source.name != 'expert_usage.txt':
            (pack / source.name).symlink_to(source.resolve(), target_is_directory=source.is_dir())
    save(ROOT / 'build-provenance.json', {
        'version': (ROOT / 'source/VERSION').read_text().strip(),
        'upstream_commit': command(['git', '-C', str(ROOT / 'source'), 'rev-parse', 'HEAD']).strip(),
        'engine_sha256': digest(EXE), 'adapter_sha256': digest(ROOT / 'mxfp8-adapter.patch'),
        'source_diff': command(['git', '-C', str(ROOT / 'source'), 'diff']),
        'untracked_source_files': command(['git', '-C', str(ROOT / 'source'), 'ls-files', '--others', '--exclude-standard']).splitlines(),
        'sequence': ['back-to-back-r0', 'back-to-back-r8192'], 'requested_pause_s': 0.0,
        'helper_gib': 28, 'target_physical_gpu': 1, 'helper_physical_gpu': 0,
        'design': 'Two fresh processes; three identical original trial-01 16K inputs per process, 512 generated tokens. First request is warm-up; two next-request transitions tested. Final resync drained before QUIT. Same smoke as v1.3.99, not a new 2K performance comparison.'})
    assert (ROOT / 'source/VERSION').read_text().strip() == '1.3.102'
    assert command(['git', '-C', str(ROOT / 'source'), 'rev-parse', 'HEAD']).strip() == 'e4eaf01f089a3e7fb2621720fac17e5cb241c223'
    try:
        smoke = []
        for resync in [0, 8192]:
            name = f'back-to-back-r{resync}'
            rows = run_case(name, True, [{**f, 'cap': 512} for f in identical], resync=resync, pause_s=0.0, purpose='interrupt_smoke')
            log = (ROOT / 'runs' / name / 'engine.stderr.log').read_text()
            assert 'expert helper resync stopped:' not in log and 'CPU fallback' not in log
            helper = [x for x in log.splitlines() if x.startswith('expert helper request_end:')]
            assert len(helper) == 3
            assert all(int(re.search(r'window_calls (\d+)', s)[1]) > 0 and int(re.search(r'columns (\d+)', s)[1]) > 0 and int(re.search(r'fallbacks (\d+)', s)[1]) == 0 for s in helper)
            resync_lines = [x for x in log.splitlines() if x.startswith('expert helper resync:')]
            assert len(resync_lines) == (3 if resync else 0)
            if resync:
                for line in resync_lines:
                    m = re.fullmatch(r'expert helper resync: (\d+) promotions in ([\d.]+) ms(?: \(stopped: the next request\))? \(longest gap between next-request checks ([\d.]+) ms\)', line)
                    assert m and 0 <= int(m[1]) <= resync
                assert 'stopped: the next request' not in resync_lines[-1], 'Final resync must drain'
            smoke.append({'case': name, 'resync': resync, 'requested_pause_s': 0.0,
                'rows': [{k: v for k, v in x.items() if k != 'output_ids'} for x in rows],
                'resync_lines': resync_lines, 'helper_request_end': helper,
                'excluded_from_primary_performance': True})
            save(ROOT / 'interrupt-smoke-summary.json', smoke)
            status('case_complete', case=name)
        enabled = next(c for c in smoke if c['resync'] == 8192)
        initial_promotions = [int(re.search(r'resync: (\d+)', line)[1]) for line in enabled['resync_lines'][:2]]
        triggered = initial_promotions == [0, 0]
        save(ROOT / 'extension-decision.json', {'immediate_interrupted_promotions': initial_promotions, 'triggered': triggered, 'policy': 'One extra 2-ms-gap probe only if both immediate transitions have zero promotions.'})
        if triggered:
            name = 'delayed-2ms-r8192'
            rows = run_case(name, True, [{**f, 'cap': 512} for f in identical], resync=8192, pause_s=0.002, purpose='interrupt_probe')
            log = (ROOT / 'runs' / name / 'engine.stderr.log').read_text()
            helper = [x for x in log.splitlines() if x.startswith('expert helper request_end:')]
            resync_lines = [x for x in log.splitlines() if x.startswith('expert helper resync:')]
            assert len(helper) == len(resync_lines) == 3
            assert all('fallbacks 0' in x for x in helper)
            assert 'expert helper resync stopped:' not in log and 'CPU fallback' not in log
            assert 'stopped: the next request' not in resync_lines[-1]
            save(ROOT / 'delayed-probe-summary.json', {'case': name, 'resync': 8192, 'requested_pause_s': 0.002, 'rows': [{k: v for k, v in x.items() if k != 'output_ids'} for x in rows], 'resync_lines': resync_lines, 'helper_request_end': helper, 'excluded_from_primary_performance': True})
        save(ROOT / 'results.json', {'separate_smoke_processes': 2, 'conditional_probe_processes': int(triggered), 'requests': 6 + 3 * int(triggered), 'measured_after_warmup': 4 + 2 * int(triggered), 'numerical_diagnostics': False, 'full_2K_performance_rerun': False})
        status('complete', processes=2 + int(triggered))
    except BaseException as error:
        save(ROOT / 'failure.json', {'error': repr(error), 'time': time.time()})
        status('failed', error=repr(error))
        raise
    finally:
        after = snapshot()
        save(ROOT / 'after.json', after)
        assert before['small_sha256'] == after['small_sha256']
        assert before['model_stats'] == after['model_stats']
        save(ROOT / 'preservation.json', {'source_pack_hashes_unchanged': True, 'model_sizes_and_mtimes_unchanged': True,
             'running_user_services_unchanged': before['services'] == after['services'],
             'gpu_compute_apps_after': command(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader']).strip()})


if __name__ == '__main__':
    def interrupted(signum, _frame):
        raise SystemExit('Interrupted by signal ' + str(signum))
    for signum in [signal.SIGTERM, signal.SIGINT, signal.SIGHUP]:
        signal.signal(signum, interrupted)
    main()

